// Select the "Add to Cart" button
const addBtn = document.querySelector("#add_to_cart_asses");

// Add click event listener to the "Add to Cart" button
addBtn.addEventListener("click", function(e) {
  e.preventDefault()
  const parentElements = document.querySelectorAll(".pro_on_mob");
  const selectedVariants = [];

  parentElements.forEach(parent => {
    const ckBox = parent.querySelector(".ck-box input:checked");
    if (ckBox) {
      const varInput = parent.querySelector(".panel-body li input");
      if (varInput) {
        const variantId = varInput.getAttribute("variant_id");
        if (variantId) {
          selectedVariants.push(variantId);
        }
      }
    }
  });

  console.log(selectedVariants);

  if (selectedVariants.length === 0) {
    console.log("No variant IDs selected.");
  } else {
    const formData = {
      items: selectedVariants.map(id => ({
        "id": id,
        "quantity": 1,
      }))
    };

    fetch("/cart/add.js", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(formData),
    })
    .then((res) => res.json())
    .then((data) => {
      console.log("Data added to cart:", data);
      const baseLocation = "https://riveladermascience.com";
      const newLocation = baseLocation + "/cart";
      window.location.href = newLocation;
    })
    .catch((err) => {
      console.error("Error adding to cart:", err);
    });
  }
});
