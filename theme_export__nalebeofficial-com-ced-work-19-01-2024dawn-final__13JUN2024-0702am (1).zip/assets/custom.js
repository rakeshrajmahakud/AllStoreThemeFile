
$(document).ready(function(){
  let allHeroVideo = document.querySelectorAll('[id^="Deferred-Poster-"]');
  for (var i = 0; i < allHeroVideo.length; i++) {
    if (allHeroVideo[i].classList.contains("video-hero-autoplay")) {
      allHeroVideo[i].click();
    }
  }
  $('[data_slider]').each(function(){
    let slider = $(this);
    let slideToShow = $(this).attr('slide-to-show') || 1;
    let slideToShow_mobile = $(this).attr('slide-to-show_mobile') || 1;
    let data_arrow = $(this).attr('data-arrow') || true;
    slideToShow = Number(slideToShow);
    slideToShow_mobile = Number(slideToShow_mobile);
    let sliderSpeed = $(this).attr("data-speed") || 3000;
    sliderSpeed = Number(sliderSpeed);
    customSlick(slider,sliderSpeed,slideToShow,slideToShow_mobile,data_arrow)
  }) 

   let items = document.querySelector(".header__inline-menu").querySelectorAll("details");
      items.forEach(item => {
        item.addEventListener("mouseover", () => {
        item.setAttribute("open", true);
        let header_data_slider = $("[header_data_slider]");
        let slickStatus = header_data_slider.hasClass('slick-initialized');
        if(slickStatus == false){
        customSlick(header_data_slider,3000,1,1,false)
        }
        item.addEventListener("mouseleave", () => {
          $(header_data_slider).slick('unslick');
          item.removeAttribute("open");
        });
      });
      });
    var src,previousEle,previousSrc
   $('body').on('mouseover','.color_swatch',function(){
     src = $(this).attr('data-src');
     previousEle = $(this).parents('.card--media').find('.motion-reduce');
     previousSrc = previousEle.attr('src');
     previousEle.attr('src',src);
     previousEle.attr('srcset',src);
    console.log(src,previousSrc);
  }).on('mouseout','.color_swatch',function(){
     previousEle.attr('src',previousSrc);
     previousEle.attr('srcset',previousSrc);
     console.log(src,previousSrc);
  })

})

function customSlick(slider,sliderSpeed,slideToShow,slideToShow_mobile,data_arrow){   

      $(slider).not('.slick-initialized').slick({ 	
        dots: true,
        arrows:data_arrow,
        infinite: false,
        slidesToShow: slideToShow,
        slidesToScroll: 1,
        autoplay:false,
        autoplaySpeed: sliderSpeed,
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: slideToShow,
              slidesToScroll: 1,
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: slideToShow_mobile,
              slidesToScroll: 1,
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: slideToShow_mobile,
              slidesToScroll: 1,
            }
          }

        ],
        prevArrow:
          '<button class="slide-arrow prev-arrow" role="button" aria-label="prev-button"> <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="chevron-left"><path id="Vector" d="M15 18.98L9 12.98L15 6.97998" stroke="black" stroke-linecap="round" stroke-linejoin="round"/></g></svg></button>',
        nextArrow:
          '<button class="slide-arrow next-arrow" role="button" aria-label="next-button"><svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="chevron-left"><path id="Vector" d="M9 18.98L15 12.98L9 6.97998" stroke="black" stroke-linecap="round" stroke-linejoin="round"/></g></svg></button>',
      });
}


    // tab section 
    $(document).on('click', '.featured-tab-btn', function (evt) {
      let blockId = $(this).attr("data-block-id");
      $(this).parent().find('.active').removeClass('active');
      $(this).addClass('active');
      $(this).parent().parent().parent().parent().parent().find('.tabcontent').css("display", "none")
      $('#featured-' + blockId).css("display", "block");
      $('[data_slider]').slick("refresh");
    });
 
    // facet drawer close functionality
  document.querySelector('.drawer_facet-close__wrapper').addEventListener('click', () => {
    document.querySelector('.mobile-facets__close').click();
});

