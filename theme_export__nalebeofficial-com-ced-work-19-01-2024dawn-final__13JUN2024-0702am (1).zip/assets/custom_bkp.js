$(document).ready(function () {
  /***
   * @hero video section start
   */
  let allHeroVideo = document.querySelectorAll('[id^="Deferred-Poster-"]');
  for (var i = 0; i < allHeroVideo.length; i++) {
    if (allHeroVideo[i].classList.contains("video-hero-autoplay")) {
      console.log(allHeroVideo[i]);
      allHeroVideo[i].click();
    }
  }
  setTimeout(function () {
    $(".hero-video-block-wrapper").each(function () {
      var slickInduvidualVideo = $(this);
      let videoBLockId = slickInduvidualVideo.attr("id");
      let blockLength = slickInduvidualVideo.attr("data-total-block");
      let sliderSpeed = slickInduvidualVideo.attr("data-speed") || 3000;
      let isSlider = ($(this).attr("data-slider") == "show") ? true : false;
      if (isSlider == false || blockLength <= 1) return;
      $("#" + videoBLockId).slick({
        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        pauseOnHover: true,
        autoplaySpeed: sliderSpeed,
        prevArrow:
          '<button class="slide-arrow prev-arrow" role="button" aria-label="prev-button"> <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="chevron-left"><path id="Vector" d="M15 18.98L9 12.98L15 6.97998" stroke="black" stroke-linecap="round" stroke-linejoin="round"/></g></svg></button>',
        nextArrow:
          '<button class="slide-arrow next-arrow" role="button" aria-label="next-button"><svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="chevron-left"><path id="Vector" d="M9 18.98L15 12.98L9 6.97998" stroke="black" stroke-linecap="round" stroke-linejoin="round"/></g></svg></button>',
      });

    });
  }, 20)

  // $(".hero-video-block-wrapper").each(function () {
  //   var slickInduvidualVideo = $(this);
  //   let videoBLockId = slickInduvidualVideo.attr("id");
  //   $("#" + videoBLockId).on('init', function (event, slick) {
  //     $("#" + videoBLockId).removeClass("custom-hide").addClass("custom-show")
  //   });
  // })



  /***
   * @hero video section end
   */

  $(".featured-product-slider").each(function () {
    var slickInduvidual = $(this);
    let iddd = slickInduvidual.attr("id");
    let blockLength = slickInduvidual.attr("data-total-block");
    let sliderSpeed = slickInduvidual.attr("data-speed") || 3000;
    let isSlider = ($(this).attr("data-slider") == "show") ? true : false;
    if (isSlider == false || blockLength <= 1) return;
    $("#" + iddd).slick({
      dots: true,
      slidesToShow: 4,
      infinite: true,
      slidesToScroll: 1,
      draggable: true,
      swipeToSlide: true,
      autoplaySpeed: sliderSpeed,
      prevArrow:
        '<button class="slide-arrow prev-arrow" role="button" aria-label="prev-button"> <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="chevron-left"><path id="Vector" d="M15 18.98L9 12.98L15 6.97998" stroke="black" stroke-linecap="round" stroke-linejoin="round"/></g></svg></button>',
      nextArrow:
        '<button class="slide-arrow next-arrow" role="button" aria-label="next-button"><svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="chevron-left"><path id="Vector" d="M9 18.98L15 12.98L9 6.97998" stroke="black" stroke-linecap="round" stroke-linejoin="round"/></g></svg></button>',
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 4,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: sliderSpeed,

          },
        },
        {
          breakpoint: 989,
          settings: {
            slidesToShow: 3,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: sliderSpeed,

          },
        },
        {
          breakpoint: 599,
          settings: {
            slidesToShow: 2,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: sliderSpeed,

          },
        },
        {
          breakpoint: 499,
          settings: {
            slidesToShow: 1,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: sliderSpeed,

          }
        }
      ],
    });
  });

  setTimeout(function () {
    $(".nav-multi-image-slider").each(function () {
      var slickInduvidual = $(this);
      let iddd = slickInduvidual.attr("id");
      // let blockLength = slickInduvidual.attr("data-total-block");
      //let sliderSpeed = slickInduvidual.attr("data-speed") || 3000;
      // let isSlider = ($(this).attr("data-slider") == "show") ? true : false;
      //if(isSlider == false || blockLength <=1) return;
      $("#" + iddd).slick({
        dots: true,
        slidesToShow: 1,
        infinite: false,
        arrows: false,
        autoplay: false
      });
    });

    $(".nav-multi-image-slider").each(function () {
      let slickInduvidualVideo = $(this);
      let videoBLockId = slickInduvidualVideo.attr("id");
      $("#" + videoBLockId).on('init', function (event, slick) {
        $("#" + videoBLockId).slick("refresh")
      });
    })
  }, 2000)


  $(".featured-product-slider").each(function () {
    let slickInduvidualVideo = $(this);
    let videoBLockId = slickInduvidualVideo.attr("id");
    $("#" + videoBLockId).on('init', function (event, slick) {
      $("#" + videoBLockId).removeClass("custom-hide").addClass("custom-show")
    });
  })

  $(".newslatter__rightblock").slick(
    {
      dots: false,
      slidesToShow: 3,
      infinite: true,
      slidesToScroll: 1,
      draggable: true,
      swipeToSlide: true,
      useCSS: true,
      arrows:false,
      responsive: [
        {
          breakpoint: 1150,
          settings: {
            slidesToShow: 2,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: 1000,

          },
        },
        {
          breakpoint: 989,
          settings: {
            slidesToShow: 2,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: 1000,

          },
        },
        {
          breakpoint: 749,
          settings: {
            slidesToShow: 2,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: 1000,

          },
        },
        {
          breakpoint: 500,
          settings: {
            slidesToShow: 1,
            infinite: true,
            slidesToScroll: 1,
            draggable: true,
            swipeToSlide: true,
            autoplaySpeed: 1000,

          },
        },
      ],
    }
  );
  $(document).on('click', '.header__menu-item', function (evt) {
    let blockId = $(this).attr("data-mega-block-id");
    $('#nav-multi-image-slider-' + blockId).slick("refresh")

  })
  $(document).on('click', '.featured-tab-btn', function (evt) {
    let blockId = $(this).attr("data-block-id");
    $(this).parent().find('.active').removeClass('active');
    $(this).addClass('active');
    $(this).parent().parent().parent().parent().parent().find('.tabcontent').css("display", "none")
    $('#featured-' + blockId).css("display", "block");
    $('#sasasssliderassas-' + blockId).slick("refresh")
  });


});
