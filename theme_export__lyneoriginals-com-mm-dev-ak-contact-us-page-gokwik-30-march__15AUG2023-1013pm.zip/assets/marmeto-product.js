class MarmetoProductCard extends HTMLElement {
  constructor() {
    super();

    this.addEventListener("click", (event) => {
      if (event.target.classList.contains("bgImg")) {
        this.variantChange(event);
        return false;
      }
    });
  }
  variantChange(event) {
    this.input = event.target.closest(".swatch-element").querySelector("input");
    this.selectedVariant = this.input.dataset.variant;
    this.productHandle = this.input.dataset.handle;
    let variantUrl = `/products/${this.productHandle}?view=mm-product-card&variant=${this.selectedVariant}`;
    fetch(variantUrl)
      .then((response) => response.text())
      .then((data) => {
        const html = new DOMParser().parseFromString(data, "text/html");
        const responseCard = html.querySelector("marmeto-product-card");
        this.innerHTML = responseCard.innerHTML;
      });
  }
}
customElements.define("marmeto-product-card", MarmetoProductCard);
