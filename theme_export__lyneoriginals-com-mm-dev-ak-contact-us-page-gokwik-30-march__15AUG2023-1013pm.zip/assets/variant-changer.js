var variant__btn = document.querySelectorAll(".swatch--color__label");
variant__btn.forEach( el => {
  el.addEventListener('click',(event)=>{
    event.target.window.alert();
  });
});