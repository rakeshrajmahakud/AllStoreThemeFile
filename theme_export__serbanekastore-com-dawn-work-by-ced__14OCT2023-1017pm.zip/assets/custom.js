  document.addEventListener("DOMContentLoaded", function() {
    footer_accordion();
  });

  function footer_accordion() {
    if (window.innerWidth < 750) {
      var accordions = document.querySelectorAll('.custom_accordian');
      for (var i = 0; i < accordions.length; i++) {
        accordions[i].classList.add('ced-accordion');
        accordions[i].nextElementSibling.classList.add('ced-accordion-content');
        accordions[i].addEventListener('click', function() {
          var accr = this.innerText.replace(/\s/g, '');
          if (this.classList.contains('active')) {
            this.classList.remove('active');
            this.nextElementSibling.classList.remove('active');
          } else {
            this.classList.add('active');
            this.nextElementSibling.classList.add('active');
          }
          var allAccordions = document.querySelectorAll('.ced-accordion');
          for (var j = 0; j < allAccordiocustom_accordianns.length; j++) {
            var acc = allAccordions[j].innerText.replace(/\s/g, '');
            if (accr !== acc) {
              allAccordions[j].classList.remove('active');
              allAccordions[j].nextElementSibling.classList.remove('active');
            }
          }
        });
      }
    }
  }