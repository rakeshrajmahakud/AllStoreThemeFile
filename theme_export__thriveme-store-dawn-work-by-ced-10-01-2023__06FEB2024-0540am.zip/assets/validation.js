/**
                          use proper naming convention with declartaion of variable where we can use snakecase var where we have to use camel case var decalrtion
                      also try to optimize the code more with exception handling	
                      **/

"use strict";
const email_pattern = /^[a-zA-Z0-9\_\.\-]+@[a-zA-Z0-9\-]+(?:\.[a-zA-Z]+)$/;
const number_pattern = /^-?\d+$/;
const string_pattern = /^[a-zA-Z]/;
const obj_status = {
  first_name_status: "",
  last_name_status: true,
  email_status: "",
  phone_status: "",
  password_status: "",
  confirm_passoword_status: "",
};
let check_validation,
  error_msg,
  submitBtn,
  Status = "false";

let init = () => {
  let form_selectors = {
    login_form: document.querySelector('[action="/account/login"]'),
    create_form: document.querySelector('[action="/account"]'),
    contact_form: document.querySelector("form#ContactForm.isolate"),
    address_form: document.querySelector('[action="/account/addresses"]'),
  };
  let Input = document.querySelectorAll('input:not([custom_id="newsletter"])');
  Input.forEach(function (Item, Index) {
    Item.addEventListener("input focusin", Validation.bind(this));
    Item.addEventListener("keyup", Validation.bind(this));
    Item.addEventListener("focusin", Validation.bind(this));
    Item.btn = form_selectors;
  });
  btnDisabled(Status, form_selectors);
};
let Validation = (evt) => {
  let evtTarget = evt.target;
  let inputType = evtTarget.type;
  switch (inputType) {
    case "email":
      check_validation = email_pattern.test(evtTarget.value);
      check_validation == true
        ? ((obj_status.email_status = true),
          Remove_Element(evtTarget),
          validation_status(obj_status, evt.currentTarget.btn))
        : (validation_status(obj_status, evt.currentTarget.btn),
          (obj_status.email_status = false),
          Create_Element(evtTarget, inputType));
      break;
    case "password":
      evtTarget.value.length < 5
        ? (validation_status(obj_status, evt.currentTarget.btn),
          (obj_status.password_status = false),
          Create_Element(evtTarget, evtTarget.type))
        : ((obj_status.password_status = true),
          validation_status(obj_status, evt.currentTarget.btn),
          Remove_Element(evtTarget));
      break;
    case "text":
      if (
        evtTarget.placeholder == "First name" ||
        evtTarget.placeholder == "Name"
      ) {
        string_pattern.test(evtTarget.value) == true &&
        evtTarget.value.length > 0
          ? ((obj_status.first_name_status = true),
            validation_status(obj_status, evt.currentTarget.btn),
            Remove_Element(evtTarget))
          : ((obj_status.first_name_status = false),
            Create_Element(evtTarget, evtTarget.type),
            validation_status(obj_status, evt.currentTarget.btn));
      } else if (evtTarget.placeholder == "Last name") {
        if (evtTarget.value.length > 0) {
          string_pattern.test(evtTarget.value) == false
            ? ((obj_status.last_name_status = false),
              Create_Element(evtTarget, evtTarget.type),
              validation_status(obj_status, evt.currentTarget.btn))
            : ((obj_status.last_name_status = true),
              validation_status(obj_status, evt.currentTarget.btn),
              Remove_Element(evtTarget));
        } else {
          obj_status.last_name_status = true;
          validation_status(obj_status, evt.currentTarget.btn);
          Remove_Element(evtTarget);
        }
      }
      break;
    case "tel":
      number_pattern.test(evtTarget.value) == false
        ? ((obj_status.phone_status = false),
          Create_Element(evtTarget, evtTarget.type),
          validation_status(obj_status, evt.currentTarget.btn))
        : ((obj_status.phone_status = true),
          validation_status(obj_status, evt.currentTarget.btn),
          Remove_Element(evtTarget));
      break;
    default:
      console.log("default", box_name);
  }
};

// disabled button

let btnDisabled = (Status, form_selectors) => {
  Object.values(form_selectors).forEach((val) => {
    submitBtn = val != null ? val.querySelector("button") : false;
    if (submitBtn != false) {
      Status != true
        ? (submitBtn.disabled = true)
        : (submitBtn.disabled = false);
    }
  });
};

// created p tag

let Create_Element = (ele, name_type) => {
  console.log(ele.value.length);
  if (ele.value.length > 0) {
    if (ele.nextElementSibling.nextElementSibling == null) {
      let element = document.createElement("p");
      element.setAttribute("style", "color:red");
      element.setAttribute("class", name_type);
      if (name_type == "email") {
        element.textContent = "Invalid Email Address";
      } else if (name_type == "password") {
        element.textContent = "Password cannot be less than 5 characters";
      } else if (name_type == "text") {
        ele.name == "customer[first_name]"
          ? (element.textContent = "First name must be start with string")
          : ele.name == "customer[last_name]"
          ? (element.textContent = "Last name must be start with string")
          : ele.name == "contact[Name]"
          ? (element.textContent = "Name must be start with string")
          : console.log();
      } else if (name_type == "tel") {
        element.textContent = "Phone number must be a number";
      }
      ele.parentNode.insertBefore(element, ele.nextsiblings);
    } else if (ele.nextElementSibling.nextElementSibling != null) {
      if (ele.value.length == 0 && ele.name == "customer[first_name]") {
        ele.nextElementSibling.nextElementSibling.textContent =
          "First name cannot be empty";
      } else if (ele.value.length == 0 && ele.name == "customer[last_name]") {
        ele.nextElementSibling.nextElementSibling.remove();
      } else if (ele.value.length > 0 && ele.name == "customer[first_name]") {
        ele.nextElementSibling.nextElementSibling.textContent =
          "First name must be start with string";
      } else if (ele.value.length == 0 && ele.name == "contact[Name]") {
        ele.nextElementSibling.nextElementSibling.textContent =
          "Name cannot be empty";
      } else if (ele.value.length > 0 && ele.name == "contact[Name]") {
        ele.nextElementSibling.nextElementSibling.textContent =
          "Name must be start with string";
      } else if (ele.value.length > 0 && name_type == "tel") {
        ele.nextElementSibling.nextElementSibling.textContent =
          "Phone number must be a number";
      } else if (ele.value.length == 0 && name_type == "tel") {
        ele.nextElementSibling.nextElementSibling.textContent =
          "Phone number cannot be empty";
      }
    }
  } else if (ele.value.length == 0) {
    if (ele.nextElementSibling.nextElementSibling != null) {
      ele.nextElementSibling.nextElementSibling.remove();
    }
  }
};

// Remove Error Message Element

let Remove_Element = (ele) => {
  let dynamicClass = ele.nextElementSibling.nextElementSibling;
  if (dynamicClass != undefined) {
    let dynamicClassAttribute = dynamicClass.getAttribute("class");
    if (ele.type == dynamicClassAttribute) {
      ele.nextElementSibling.nextElementSibling != null
        ? ele.nextElementSibling.nextElementSibling.remove()
        : console.log();
    }
  }
};

//	Check Status of form

let validation_status = (obj_status, form_selectors) => {
  if (
    obj_status.email_status == true &&
    obj_status.password_status == true &&
    form_selectors.login_form != null
  ) {
    Status = true;
    btnDisabled(Status, form_selectors);
  } else if (
    obj_status.first_name_status == true &&
    obj_status.email_status == true &&
    obj_status.password_status == true &&
    form_selectors.create_form != null &&
    obj_status.last_name_status != false
  ) {
    Status = true;
    btnDisabled(Status, form_selectors);
  } else if (
    obj_status.first_name_status == true &&
    obj_status.email_status == true &&
    obj_status.phone_status == true &&
    form_selectors.contact_form != null
  ) {
    Status = true;
    btnDisabled(Status, form_selectors);
  } else if (
    obj_status.first_name_status == true &&
    obj_status.phone_status == true &&
    form_selectors.address_form != null &&
    obj_status.last_name_status != false
  ) {
    Status = true;
    btnDisabled(Status, form_selectors);
  } else {
    Status = false;
    btnDisabled(Status, form_selectors);
  }
};
init();
