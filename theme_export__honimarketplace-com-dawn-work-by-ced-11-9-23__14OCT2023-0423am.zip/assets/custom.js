// Scroll to the desired section on click
// function scrollToSection(event) {
//   event.preventDefault();
//   var $section = $($(this).attr('href')); 
//   $('html, body').animate({
//     scrollTop: $section.offset().top
//   }, 600);
// }
// $('[data-scroll]').on('click', scrollToSection);

$(document).ready(function(){
    footer_accordion();
  product_description_accordion();
  $(".spr-stars").click(function() {
    $('html,body').animate({
            scrollTop: $("#shopify-section-template--19985189568822__169226418063241c7c").offset().top
        },
        'slow');
});
})
function product_description_accordion(){
  var existing_classes=$('.product_description_accordion').next().attr('class')+' product_description_accordion-content';
    $('.product_description_accordion').next().attr('class',existing_classes);
  $('.product_description_accordion').click(function(){
    if($(this).next().hasClass('active')){
         $(this).next().removeClass('active');
         $(this).next().removeClass('active');
     
      $(this).removeClass('accordion');
       $(this).addClass('accordionn');
      }
      else{
        $(this).next().addClass('active');
        
        $(this).removeClass('accordionn');
        $(this).addClass('accordion');
        
      }
  })
}



                  
 function footer_accordion(){                 
 if($(window).width()<=768)
  {
        $('.footer-block__heading').addClass('accordion');
        var existing_classes=$('.accordion').next().attr('class')+' accordion-content';
        $('.accordion').next().attr('class',existing_classes);
        $('.accordion').click(function(){
        var accr = $(this).text();
        accr = accr.replace(" ", "");
        if($(this).hasClass('active')){
           $(this).removeClass('active');
           $(this).next().removeClass('active');
        }
        else{
          $(this).addClass('active');
          $(this).next().addClass('active');
        }
        $('.accordion').each(function(){
          var acc = $(this).text();
          acc = acc.replace(" ", "");
          if(accr != acc){
            $(this).removeClass('active');
            $(this).next().removeClass('active');
          }
        });
    })
  }
}