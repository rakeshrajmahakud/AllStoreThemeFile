
document.addEventListener("DOMContentLoaded", function() {
    footer_accordion();
  });

  function footer_accordion() {
    if (window.innerWidth < 750) {
      var accordions = document.querySelectorAll('.custom_accordian1');
      for (var i = 0; i < accordions.length; i++) {
        accordions[i].classList.add('ced-accordion');
        accordions[i].nextElementSibling.classList.add('ced-accordion-content');
        accordions[i].addEventListener('click', function() {
          var accr = this.innerText.replace(/\s/g, '');
          if (this.classList.contains('active2')) {
            this.classList.remove('active2');
            this.nextElementSibling.classList.remove('active2');
          } else {
            this.classList.add('active2');
            this.nextElementSibling.classList.add('active2');
          }
          var allAccordions = document.querySelectorAll('.ced-accordion');
          for (var j = 0; j < allAccordions.length; j++) {
            var acc = allAccordions[j].innerText.replace(/\s/g, '');
            if (accr !== acc) {
              allAccordions[j].classList.remove('active2');
              allAccordions[j].nextElementSibling.classList.remove('active2');
            }
          }
        });
      }
    }
  }