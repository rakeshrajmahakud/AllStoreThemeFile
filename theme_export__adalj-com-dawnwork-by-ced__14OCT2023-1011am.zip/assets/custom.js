  document.addEventListener("DOMContentLoaded", function() {
    footer_accordion();
  });

  function footer_accordion() {
    if (window.innerWidth < 750) {
      var accordions = document.querySelectorAll('.custom_accordian');
      for (var i = 0; i < accordions.length; i++) {
        accordions[i].classList.add('ced-accordion');
        accordions[i].nextElementSibling.classList.add('ced-accordion-content');
        accordions[i].addEventListener('click', function() {
          var accr = this.innerText.replace(/\s/g, '');
          if (this.classList.contains('active')) {
            this.classList.remove('active');
            this.nextElementSibling.classList.remove('active');
          } else {
            this.classList.add('active');
            this.nextElementSibling.classList.add('active');
          }
          var allAccordions = document.querySelectorAll('.ced-accordion');
          for (var j = 0; j < allAccordions.length; j++) {
            var acc = allAccordions[j].innerText.replace(/\s/g, '');
            if (accr !== acc) {
              allAccordions[j].classList.remove('active');
              allAccordions[j].nextElementSibling.classList.remove('active');
            }
          }
        });
      }
    }
  }


// image with text section
// we are using intersection observer api to observerve element to come in view port and after that we add animation class on it .
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const left = entry.target.querySelectorAll('.left_image')
      const right = entry.target.querySelectorAll('.right_image')
      
      left.forEach((el)=>{
        if (entry.isIntersecting) {
          el.classList.add('left_image--anime');
    	  return; // if we added the class, exit the function
        }
    
        // We're not intersecting, so remove the class!
        el.classList.remove('left_image--anime');
      })
      
      right.forEach((el)=>{
        if (entry.isIntersecting) {
          el.classList.add('right_image--anime');
    	  return; // if we added the class, exit the function
        }
    
        // We're not intersecting, so remove the class!
        el.classList.remove('right_image--anime');
      })  
    });
  });
  
  let imageWithText = document.querySelectorAll('.image-with-text__grid')
  imageWithText.forEach((el)=>{
    observer.observe(el)
  })