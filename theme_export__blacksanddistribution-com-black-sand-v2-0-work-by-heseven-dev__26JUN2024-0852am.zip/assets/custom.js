
function increaseCount(a, b) {
    console.log(b.getAttribute('dataqtytarget'));
    var qtySelector = b.getAttribute('dataqtytarget');
    var input = b.previousElementSibling;
    var value = parseInt(input.value, 10); 
    value = isNaN(value)? 0 : value;
    value ++;
    input.value = value;
    document.querySelector('#'+qtySelector).value = value;

}
function decreaseCount(a, b) {    
    var qtySelector = b.getAttribute('dataqtytarget');
    var input = b.nextElementSibling;
    var value = parseInt(input.value, 10); 
    if (value > 1) {
      value = isNaN(value)? 0 : value;
      value --;
      input.value = value;
      document.querySelector('#'+qtySelector).value = value;
    }
}
  
function myFunction(a, b) {
    console.log(b);
    var qtySelector = b.getAttribute('dataqtytarget');
    let input_value = b.value;
    document.querySelector('#'+qtySelector).value = input_value;
    console.log(input_value);
}


// custom contact form with image js code
document.addEventListener('DOMContentLoaded', function() {
  let submitButton = document.querySelector('.submitt');
  let contactForm = document.getElementById('contact_form');

  submitButton.addEventListener('click', function(event) {
    event.preventDefault();
    contactForm.submit();
  });
});
class CustomSplide extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    // Initialize Splide when the element is added to the DOM
    this.initSplide();
  }

  initSplide() {
    const splide = new Splide('.splide');
    splide.mount();
  }
}
customElements.define('custom-splide', CustomSplide);

// custom accordion code 
let accordian = document.querySelectorAll('.accordian');
accordian.length && accordian.forEach((element)=>{
    let icon = element.querySelector('.custom-icon-arrow');
    let answer = element.querySelector('.answer');
    element.addEventListener('click',()=>{
        // icon.classList.toggle('open');
        // answer.classList.toggle('open');
        if (icon.classList.contains('open')){
            icon.classList.remove('open');
            answer.style.maxHeight = null;
        }else{
            icon.classList.add('open');
            answer.style.maxHeight = answer.scrollHeight + 'px';
        }
    })
})