//initialize the slider inside a custom element 

class TestimonialSplide extends HTMLElement{
  constructor(){
    super()
    this.init()
  }
  init(){
      let testimonial_splide = new Splide( '.testimonial-splide' ,{
      perPage: 2,
      rewind : true,
      pagination: false,
      gap : '2rem',
      autoplay: false,
      breakpoints: {
        1024: {
          perPage: 2,
          gap    : '.7rem'
          
        },
        990: {
          perPage: 1,
          gap    : '.7rem'
          
        },      
        749: {
          perPage: 2,
          gap    : '.7rem'
        },
        480: {
          perPage: 1,
        },
      },
    });
    testimonial_splide.mount();
  }
}
customElements.define('testimonial-slider', TestimonialSplide);

// button click to slide functionality  
let prev_testi =  document.querySelector('.testimonial_prev--btn');
let next_testi =  document.querySelector('.testimonial_next--btn');

prev_testi.addEventListener('mouseup',function(){
  document.querySelector('.testimonial_splide-prev-btn').click();
  prev_testi.classList.remove('pressed');
});
prev_testi.addEventListener('mousedown',function(){
  prev_testi.classList.add('pressed');
});
next_testi.addEventListener('mouseup',function(){
  document.querySelector('.testomonial_splide-next-btn').click();
  next_testi.classList.remove('pressed');
});
next_testi.addEventListener('mousedown',function(){
  next_testi.classList.add('pressed');
}); 