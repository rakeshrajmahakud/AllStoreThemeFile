  document.addEventListener("DOMContentLoaded", function() {
    footer_accordion();
  });

  function footer_accordion() {
    if (window.innerWidth < 750) {
      var accordions = document.querySelectorAll('.custom_accordian');
      for (var i = 0; i < accordions.length; i++) {
        accordions[i].classList.add('ced-accordion');
        accordions[i].nextElementSibling.classList.add('ced-accordion-content');
        accordions[i].addEventListener('click', function() {
          var accr = this.innerText.replace(/\s/g, '');
          if (this.classList.contains('active')) {
            this.classList.remove('active');
            this.nextElementSibling.classList.remove('active');
          } else {
            this.classList.add('active');
            this.nextElementSibling.classList.add('active');
          }
          var allAccordions = document.querySelectorAll('.ced-accordion');
          for (var j = 0; j < allAccordions.length; j++) {
            var acc = allAccordions[j].innerText.replace(/\s/g, '');
            if (accr !== acc) {
              allAccordions[j].classList.remove('active');
              allAccordions[j].nextElementSibling.classList.remove('active');
            }
          }
        });
      }
    }
  }


// image with text section
// we are using intersection observer api to observerve element to come in view port and after that we add animation class on it .
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const left = entry.target.querySelectorAll('.left_image')
      const right = entry.target.querySelectorAll('.right_image')
      
      left.forEach((el)=>{
        if (entry.isIntersecting) {
          el.classList.add('left_image--anime');
    	  return; // if we added the class, exit the function
        }
    
        // We're not intersecting, so remove the class!
        el.classList.remove('left_image--anime');
      })
      
      right.forEach((el)=>{
        if (entry.isIntersecting) {
          el.classList.add('right_image--anime');
    	  return; // if we added the class, exit the function
        }
    
        // We're not intersecting, so remove the class!
        el.classList.remove('right_image--anime');
      })  
    });
  });
  
  let imageWithText = document.querySelectorAll('.image-with-text__grid')
  imageWithText.forEach((el)=>{
    observer.observe(el)
  })

// custom product card image change on click//
class CustomImage extends HTMLElement{
    constructor(){
    super()
    this.init()
  }
    init(){
      let customImage = this.querySelector('.custom_product_img');
      const csPrevbtn = this.querySelector('.card_imageslide-btn .prev');
      const csNextBtn = this.querySelector('.card_imageslide-btn .next');
      customImage = Array.from(customImage.children);

      let currentIndex = 0;
      let isTransitioning = false;
      
      function debounce(func, delay) {
          let timer;
          return function () {
              clearTimeout(timer);
              timer = setTimeout(() => {
                  func.apply(this, arguments);
              }, delay);
          };
      }

      function handleButtonClick(direction) {
          if (!isTransitioning) {
              isTransitioning = true;
              customImage[currentIndex].classList.add('imghide');
      
              if (direction === 'next' && currentIndex < customImage.length - 1) {
                  currentIndex++;
              } else if (direction === 'prev' && currentIndex > 0) {
                  currentIndex--;
              }
      
              customImage[currentIndex].classList.remove('imghide');  
              updateButtonState();
      
              setTimeout(() => {
                  isTransitioning = false;
              }, 500); // Adjust the transition time as needed
          }
      }

      function updateButtonState() {
          csPrevbtn.disabled = currentIndex === 0;
          csNextBtn.disabled = currentIndex === customImage.length - 1;
      }

      const debouncedNextClick = debounce(() => handleButtonClick('next'), 100);
      const debouncedPrevClick = debounce(() => handleButtonClick('prev'), 100);
      
      csNextBtn.addEventListener('click', debouncedNextClick);
      csPrevbtn.addEventListener('click', debouncedPrevClick);
    }
}
customElements.define('custom-image', CustomImage);

