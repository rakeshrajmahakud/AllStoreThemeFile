const scriptURL =
  "https://script.google.com/macros/s/AKfycbwamlbHRnAaR58FH_wjw4xXIxQ64_g-X4S8MDpI0tuVTA3sn8uklYlhg5rX_25klKDG8Q/exec";
const form = document.forms["YOUR_WEBAPP_URL"];

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const formData = new FormData(form);
  formData.append("Date", new Date().toLocaleDateString());
  formData.append("Time", new Date().toLocaleTimeString());

  fetch(scriptURL, { method: "POST", body: formData })
    .then((response) => {
      form.reset();
      document
        .querySelector(".form-success_message")
        .classList.remove("d-none");
    })
    .catch((error) => {
      console.error("Error:", error.message);
    });
});

const checkboxEle = document.querySelector("#terms-and-conditons");

if (checkboxEle !== null) {
  if (checkboxEle.checked) {
    checkboxEleValue = "checked";
  } else {
    checkboxEleValue = "unchecked";
  }
}
